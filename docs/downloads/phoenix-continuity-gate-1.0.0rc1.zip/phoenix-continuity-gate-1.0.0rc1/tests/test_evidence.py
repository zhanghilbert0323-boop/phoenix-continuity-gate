"""Real command runs must not be confused with claims or stale snapshots."""

import copy
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from phoenix_continuity_gate.evidence import assess_record, record_command, LOG_LIMIT


def git(repo, *args):
    return subprocess.run(["git", "-C", str(repo), *args], check=True,
                          capture_output=True, text=True).stdout.strip()


class EvidenceTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory(prefix="phoenix-evidence-test-")
        self.addCleanup(temp.cleanup)
        self.base = Path(temp.name)
        self.repo = self.base / "repo with spaces"
        self.repo.mkdir()
        self.output = self.base / "run.json"
        git(self.repo, "init", "-q")
        git(self.repo, "config", "user.name", "Evidence Test")
        git(self.repo, "config", "user.email", "test@example.invalid")
        git(self.repo, "config", "commit.gpgSign", "false")
        git(self.repo, "config", "core.hooksPath", str(self.base / "no-hooks"))
        (self.repo / "app.py").write_text("def add(a, b):\n    return a + b\n", encoding="utf-8")
        (self.repo / "test_app.py").write_text(
            "import unittest\nfrom app import add\nclass Tests(unittest.TestCase):\n"
            "    def test_add(self):\n        self.assertEqual(add(2, 3), 5)\n", encoding="utf-8")
        git(self.repo, "add", ".")
        git(self.repo, "commit", "-qm", "fixture")

    def run_command(self, code="print('observed')", **kwargs):
        return record_command(self.repo, self.output, [sys.executable, "-B", "-c", code], **kwargs)

    def test_real_unittest_run_and_json_roundtrip(self):
        record = record_command(self.repo, self.output,
                                [sys.executable, "-B", "-m", "unittest", "-v"])
        saved = json.loads(self.output.read_text(encoding="utf-8"))
        self.assertEqual(record, saved)
        self.assertIn("Ran 1 test", record["execution"]["stderr"]["text"])
        result = assess_record(saved, self.repo)
        self.assertEqual((result["verdict"], result["execution"], result["freshness"]),
                         ("PASS", "SUCCEEDED", "MATCH"))

    def test_failure_is_recorded_and_blocked(self):
        record = self.run_command("assert 2 + 2 == 5")
        self.assertNotEqual(record["execution"]["exit_code"], 0)
        self.assertIn("AssertionError", record["execution"]["stderr"]["text"])
        self.assertEqual(assess_record(record, self.repo)["verdict"], "BLOCK")

    def test_new_commit_stales_previously_successful_record(self):
        record = self.run_command()
        (self.repo / "app.py").write_text("broken\n", encoding="utf-8")
        git(self.repo, "add", ".")
        git(self.repo, "commit", "-qm", "change")
        result = assess_record(record, self.repo)
        self.assertEqual((result["execution"], result["freshness"], result["verdict"]),
                         ("SUCCEEDED", "CHANGED", "BLOCK"))
        self.assertIn('CONTENT_CHANGED: "app.py"', result["findings"])

    def test_changed_bytes_even_when_git_assumes_unchanged(self):
        record = self.run_command()
        git(self.repo, "update-index", "--assume-unchanged", "app.py")
        (self.repo / "app.py").write_text("different contents\n", encoding="utf-8")
        self.assertEqual(git(self.repo, "status", "--porcelain"), "")
        self.assertEqual(assess_record(record, self.repo)["freshness"], "CHANGED")

    def test_successful_command_changing_files_requires_review(self):
        record = self.run_command("from pathlib import Path; Path('app.py').write_text('changed')")
        result = assess_record(record, self.repo)
        self.assertEqual((result["execution"], result["freshness"], result["verdict"]),
                         ("SUCCEEDED", "UNSTABLE_DURING_RUN", "REVIEW"))
        self.assertIn('CONTENT_CHANGED: "app.py"', result["findings"])
        self.assertTrue(any("BEFORE and AFTER" in line for line in result["findings"]))

    def test_deleted_tracked_file_is_stale(self):
        record = self.run_command()
        (self.repo / "app.py").unlink()
        result = assess_record(record, self.repo)
        self.assertEqual((result["freshness"], result["verdict"]), ("CHANGED", "BLOCK"))
        self.assertIn('MISSING_ON_DISK: "app.py"', result["findings"])

    def test_timeout_is_saved_without_success(self):
        record = self.run_command("import time; time.sleep(30)", timeout=0.1)
        self.assertEqual(record["execution"]["status"], "TIMED_OUT")
        self.assertIsNone(record["execution"]["exit_code"])
        self.assertEqual(assess_record(record, self.repo)["verdict"], "BLOCK")

    def test_missing_executable_is_saved_without_success(self):
        record = record_command(self.repo, self.output, [str(self.base / "missing-program")])
        self.assertEqual(record["execution"]["status"], "START_FAILED")
        self.assertEqual(assess_record(record, self.repo)["verdict"], "BLOCK")

    def test_dirty_repo_is_rejected_before_command_execution(self):
        (self.repo / "untracked.txt").write_text("dirty", encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "clean Git"):
            self.run_command("raise RuntimeError('must not run')")
        self.assertFalse(self.output.exists())

    def test_output_inside_repo_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "outside"):
            record_command(self.repo, self.repo / "record.json", [sys.executable, "-c", "pass"])

    def test_existing_record_is_preserved_and_command_not_run(self):
        self.output.write_text("keep this", encoding="utf-8")
        with self.assertRaises(FileExistsError):
            self.run_command("from pathlib import Path; Path('sentinel').touch()")
        self.assertEqual(self.output.read_text(encoding="utf-8"), "keep this")
        self.assertFalse((self.repo / "sentinel").exists())

    def test_inspection_never_executes_stored_command(self):
        record = self.run_command()
        record["command"] = [sys.executable, "-c", "from pathlib import Path; Path('sentinel').touch()"]
        assess_record(record, self.repo)
        self.assertFalse((self.repo / "sentinel").exists())

    def test_contradictory_or_missing_evidence_is_rejected(self):
        record = self.run_command()
        bad = copy.deepcopy(record)
        bad["execution"]["exit_code"] = 1
        with self.assertRaisesRegex(ValueError, "contradicts"):
            assess_record(bad, self.repo)
        with self.assertRaises(ValueError):
            assess_record({"tests": {"status": "passed"}}, self.repo)

    def test_missing_post_snapshot_is_unknown(self):
        record = self.run_command()
        record["snapshot_after"] = None
        record["snapshot_error"] = "simulated observation failure"
        result = assess_record(record, self.repo)
        self.assertEqual((result["freshness"], result["verdict"]), ("UNKNOWN", "REVIEW"))

    def test_log_tail_is_bounded(self):
        record = self.run_command(f"print('x' * {LOG_LIMIT * 2})")
        stdout = record["execution"]["stdout"]
        self.assertTrue(stdout["truncated"])
        self.assertLessEqual(len(stdout["text"]), LOG_LIMIT)

    def test_invalid_timeouts_never_execute(self):
        for timeout in (0, -1, float('inf'), float('nan')):
            with self.subTest(timeout=timeout), self.assertRaises(ValueError):
                self.run_command(timeout=timeout)
        self.assertFalse(self.output.exists())

    def test_cli_json_inspect_preserves_verdicts_and_never_runs_stored_command(self):
        project = Path(__file__).resolve().parents[1]
        record = self.run_command("print('PRIVATE_LOG_MARKER')")
        sentinel = self.base / "must-not-exist"
        record["command"] = [sys.executable, "-c", f"from pathlib import Path; Path({str(sentinel)!r}).touch()"]

        def inspect(payload, expected_code):
            self.output.write_text(json.dumps(payload), encoding="utf-8")
            result = subprocess.run([sys.executable, "-B", "-m", "phoenix_continuity_gate", "inspect",
                                     "--repo", str(self.repo), "--record", str(self.output), "--json"],
                                    cwd=project, capture_output=True, text=True, timeout=30)
            self.assertEqual(result.returncode, expected_code, result.stderr)
            self.assertEqual(result.stderr, "")
            self.assertNotIn("PRIVATE_LOG_MARKER", result.stdout)
            report = json.loads(result.stdout)
            self.assertEqual(report["report_schema_version"], 1)
            self.assertEqual(report["assessment_status"], "ASSESSED")
            self.assertIsNone(report["error"])
            self.assertFalse(sentinel.exists())
            return report

        fresh = inspect(record, 0)
        self.assertEqual((fresh["verdict"], fresh["execution"], fresh["freshness"]), ("PASS", "SUCCEEDED", "MATCH"))
        unknown = copy.deepcopy(record)
        unknown["snapshot_after"] = None
        review = inspect(unknown, 1)
        self.assertEqual((review["verdict"], review["freshness"]), ("REVIEW", "UNKNOWN"))
        (self.repo / "app.py").write_text("changed\n", encoding="utf-8")
        stale = inspect(record, 2)
        self.assertEqual((stale["verdict"], stale["freshness"]), ("BLOCK", "CHANGED"))
        self.assertIn('CONTENT_CHANGED: "app.py"', stale["findings"])

    def test_cli_json_inspect_reports_invalid_input_without_traceback(self):
        project = Path(__file__).resolve().parents[1]
        for data in (None, "{malformed", "[]"):
            with self.subTest(data=data):
                record_path = self.base / "bad.json"
                if data is not None:
                    record_path.write_text(data, encoding="utf-8")
                result = subprocess.run([sys.executable, "-B", "-m", "phoenix_continuity_gate", "inspect",
                                         "--repo", str(self.repo), "--record", str(record_path), "--json"],
                                        cwd=project, capture_output=True, text=True, timeout=30)
                self.assertEqual(result.returncode, 2)
                self.assertEqual(result.stderr, "")
                report = json.loads(result.stdout)
                self.assertEqual(report["assessment_status"], "ERROR")
                self.assertEqual(report["verdict"], "BLOCK")
                self.assertEqual(report["execution"], "UNKNOWN")
                self.assertEqual(report["freshness"], "UNKNOWN")
                self.assertEqual(report["error"]["code"], "CANNOT_ASSESS")
                self.assertTrue(report["error"]["message"])

    def test_cli_roundtrip_stale_record_and_new_record(self):
        project = Path(__file__).resolve().parents[1]

        def cli(*args):
            return subprocess.run([sys.executable, "-B", "-m", "phoenix_continuity_gate", *args],
                                  cwd=project, capture_output=True, text=True, timeout=30)

        first = cli("record", "--repo", str(self.repo), "--output", str(self.output),
                    "--", sys.executable, "-B", "-m", "unittest", "-v")
        self.assertEqual(first.returncode, 0, first.stderr)
        self.assertIn("Execution: SUCCEEDED", first.stdout)
        original_bytes = self.output.read_bytes()
        bom_record = self.base / "windows-editor-copy.json"
        bom_record.write_bytes(b"\xef\xbb\xbf" + original_bytes)
        bom_fresh = cli("inspect", "--repo", str(self.repo), "--record", str(bom_record))
        self.assertEqual(bom_fresh.returncode, 0, bom_fresh.stderr)
        self.assertIn("Freshness: MATCH", bom_fresh.stdout)
        (self.repo / "README.md").write_text("documentation change", encoding="utf-8")
        git(self.repo, "add", ".")
        git(self.repo, "commit", "-qm", "docs")
        stale = cli("inspect", "--repo", str(self.repo), "--record", str(self.output))
        self.assertEqual(stale.returncode, 2, stale.stderr)
        self.assertIn("Freshness: CHANGED", stale.stdout)
        self.assertIn('ADDED_TO_TRACKED_SET: "README.md"', stale.stdout)
        bom_stale = cli("inspect", "--repo", str(self.repo), "--record", str(bom_record))
        self.assertEqual(bom_stale.returncode, 2, bom_stale.stderr)
        self.assertIn("Freshness: CHANGED", bom_stale.stdout)
        self.assertEqual(bom_record.read_bytes(), b"\xef\xbb\xbf" + original_bytes)
        next_record = self.base / "next.json"
        fresh = cli("record", "--repo", str(self.repo), "--output", str(next_record),
                    "--", sys.executable, "-B", "-m", "unittest", "-v")
        self.assertEqual(fresh.returncode, 0, fresh.stderr)
        self.assertEqual(self.output.read_bytes(), original_bytes)
        reread = cli("inspect", "--repo", str(self.repo), "--record", str(next_record))
        self.assertEqual(reread.returncode, 0, reread.stderr)
        self.assertIn("Freshness: MATCH", reread.stdout)


if __name__ == "__main__":
    unittest.main()
